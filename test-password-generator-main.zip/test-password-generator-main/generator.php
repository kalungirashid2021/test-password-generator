<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>password generator</title>
</head>
<body>
    <form action="">

    <label for="email">email</label>
    <!-- what do mean with label for email -->
            <input type="email"><br>
        <label for="pass">password</label>
        <input type="password"> <br> <br>
        <input type="submit" value="generate password">
        <input type="submit" value="submit password">
    </form>
</body>
</html>